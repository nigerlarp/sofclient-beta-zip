# SofClient - Fabric Minecraft Client Mod
## Version 1.0.0 | Minecraft 1.21.11

Built around you.

---

## 🚀 How to Compile & Install

### Requirements
- Java 21+ ([Download](https://adoptium.net/))
- IntelliJ IDEA (recommended) or any IDE
- Internet connection (Gradle downloads dependencies)

### Steps
1. **Open project** in IntelliJ IDEA (File > Open > select this folder)
2. Wait for Gradle sync to complete (bottom status bar)
3. Open terminal in IntelliJ and run:
   ```
   ./gradlew build
   ```
   (Windows: `gradlew.bat build`)
4. Find the JAR at: `build/libs/sofclient-1.0.0.jar`
5. Copy it to `.minecraft/mods/`
6. Launch Minecraft with **Fabric Loader 0.18.1 or newer** for 1.21.11

---

## 🎮 Controls

| Key | Action |
|-----|--------|
| **RIGHT SHIFT** | Open SofClient GUI |

---

## 📦 Modules

### ⚔️ Combat
- Auto Totem, Auto Crystal, Anchor Macro, Double Anchor
- Inv Totem, AimAssist, Hitbox, TriggerBot
- Crystal Optimizer, SOS Chunk Finder, Auto Hit Crystal
- Name Protect, Black Outline, Aspect Ratio, SOS Chunk V2

### ⚙️ Misc
- Sign Protect, Name Protect, FreeCam, Auto TPA
- AutoClicker, Auto Tool, Fast Use, Name Tags
- Fake Pay, Weather Notifier, Fake Stats, Fake Loot Drop
- Armor Tracker, Custom Crosshair, Staff List, Custom Glint
- Custom FOV, Coord Snapper, Auto Walk, Zoom, Free Look
- Spawner Protect, Gambler Grinder, Panic Order, Relog Method

### 🖼️ Render
- Block ESP, Storage ESP, Block Entities ESP, Hole ESP
- FullBright, Player ESP, Mob ESP, Spawner Name Tags
- Spawner Beam, Cluster ESP, Sus Chunk Finder, Chunk Finder, Region PvP

### 💜 Visuals
- Custom Bloom, Hit Particles, Target ESP, Cosmetics (Wings/Crown/Mini You)
- Luma, Aurora, Crystal Pulse, Motion Blur, Sky

### > Client
- HUD, Spotify HUD, Chat Macro, Config Share
- Animations, B73 Jump Circles, Creamy Keys, ClickGUI
- Music HUD, Free Loan

---

## 🎨 Themes
Default (Pink) · Pink · Blue · Green · Purple · Red · **Rainbow** · Custom

---

## 🖥️ GUI Modes
- **Panel** — floating category columns (like old-school clients)
- **Dropdown** — modern single window with sidebar navigation

