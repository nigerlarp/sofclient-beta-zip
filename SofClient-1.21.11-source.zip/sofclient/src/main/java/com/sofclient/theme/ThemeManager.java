package com.sofclient.theme;

import java.awt.Color;

public class ThemeManager {

    public enum Theme {
        DEFAULT("Default"),
        PINK("Pink"),
        BLUE("Blue"),
        GREEN("Green"),
        PURPLE("Purple"),
        RED("Red"),
        RAINBOW("Rainbow"),
        CUSTOM("Custom");

        public final String displayName;
        Theme(String n) { this.displayName = n; }
    }

    private Theme current = Theme.DEFAULT;
    private int customColor = 0xFFFF6EB4;
    private float rainbowOffset = 0f;

    // Tick rainbow animation
    public void tick() {
        rainbowOffset = (rainbowOffset + 0.005f) % 1.0f;
    }

    public int getAccentColor() {
        return switch (current) {
            case DEFAULT -> 0xFFFF6EB4; // Soft pink like 67client
            case PINK    -> 0xFFFF4FA3;
            case BLUE    -> 0xFF4FA8FF;
            case GREEN   -> 0xFF4FFF9A;
            case PURPLE  -> 0xFFB44FFF;
            case RED     -> 0xFFFF4F4F;
            case RAINBOW -> getRainbow(rainbowOffset);
            case CUSTOM  -> customColor;
        };
    }

    public int getRainbow(float offset) {
        float hue = (offset % 1.0f + 1.0f) % 1.0f;
        return Color.HSBtoRGB(hue, 0.9f, 1.0f) | 0xFF000000;
    }

    public int getRainbowForIndex(int index, int total) {
        float offset = rainbowOffset + (float) index / total;
        return getRainbow(offset);
    }

    // Colors used in UI
    public int getBg()          { return 0xEE0D0D14; } // Very dark bg
    public int getBg2()         { return 0xEE141420; } // Slightly lighter panel
    public int getBgHover()     { return 0xEE1E1E2E; }
    public int getBorder()      { return 0x33FFFFFF; }
    public int getText()        { return 0xFFE0E0E0; }
    public int getTextDim()     { return 0xFF888888; }
    public int getEnabled()     { return getAccentColor(); }
    public int getDisabled()    { return 0xFF444455; }
    public int getToggleTrack() { return 0xFF2A2A3A; }
    public int getSliderFill()  { return getAccentColor(); }
    public int getSliderBg()    { return 0xFF2A2A3A; }

    public Theme getCurrent() { return current; }
    public void setCurrent(Theme t) { current = t; }
    public int getCustomColor() { return customColor; }
    public void setCustomColor(int c) { customColor = c; }
    public float getRainbowOffset() { return rainbowOffset; }
}
