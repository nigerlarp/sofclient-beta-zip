package com.sofclient;

import com.sofclient.config.ConfigManager;
import com.sofclient.gui.hud.HudRenderer;
import com.sofclient.gui.welcome.WelcomeScreen;
import com.sofclient.modules.ModuleManager;
import com.sofclient.theme.ThemeManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SofClient implements ClientModInitializer {

    public static final String NAME = "SofClient";
    public static final String VERSION = "1.0.0";
    public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

    public static ModuleManager moduleManager;
    public static ConfigManager configManager;
    public static ThemeManager themeManager;
    public static HudRenderer hudRenderer;

    public static KeyBinding openGuiKey;
    public static boolean firstLaunch = true;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[{}] Loading v{}...", NAME, VERSION);

        configManager = new ConfigManager();
        themeManager = new ThemeManager();
        moduleManager = new ModuleManager();
        hudRenderer = new HudRenderer();

        firstLaunch = configManager.isFirstLaunch();

        // Open GUI key (default: RIGHT_SHIFT)
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.sofclient.opengui",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            "category.sofclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Show welcome screen on first launch
            if (firstLaunch && client.player != null && client.currentScreen == null) {
                firstLaunch = false;
                client.setScreen(new WelcomeScreen());
                return;
            }

            while (openGuiKey.wasPressed()) {
                if (client.player != null) {
                    openMainGui(client);
                }
            }

            moduleManager.onTick(client);
        });

        HudRenderCallback.EVENT.register((ctx, delta) -> hudRenderer.render(ctx, delta));

        LOGGER.info("[{}] Loaded successfully!", NAME);
    }

    public static void openMainGui(MinecraftClient client) {
        String guiStyle = configManager.getGuiStyle();
        if ("PANEL".equals(guiStyle)) {
            client.setScreen(new com.sofclient.gui.panel.PanelScreen());
        } else {
            client.setScreen(new com.sofclient.gui.dropdown.DropdownScreen());
        }
    }
}
