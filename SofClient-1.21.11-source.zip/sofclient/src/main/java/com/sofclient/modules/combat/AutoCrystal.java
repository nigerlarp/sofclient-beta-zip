package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class AutoCrystal extends Module {
    public AutoCrystal(){super("AutoCrystal","Combat module: AutoCrystal",Category.COMBAT);}
}
