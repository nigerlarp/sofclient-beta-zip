package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class FreeLoan extends Module {
    public FreeLoan(){super("FreeLoan","Client module",Category.CLIENT);}
}
