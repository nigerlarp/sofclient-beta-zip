package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class SosChunkV2 extends Module {
    public SosChunkV2(){super("SosChunkV2","Combat module: SosChunkV2",Category.COMBAT);}
}
