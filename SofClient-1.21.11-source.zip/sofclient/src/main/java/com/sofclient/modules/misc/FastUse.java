package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FastUse extends Module {
    public FastUse(){super("FastUse","Misc module",Category.MISC);}
}
