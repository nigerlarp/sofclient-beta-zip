package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class AutoTool extends Module {
    public AutoTool(){super("AutoTool","Misc module",Category.MISC);}
}
