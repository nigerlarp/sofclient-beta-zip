package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class BlockEsp extends Module {
    public BlockEsp(){super("BlockEsp","Render module",Category.RENDER);}
}
