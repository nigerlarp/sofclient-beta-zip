package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class StrangeEsp extends Module {
    public StrangeEsp(){super("StrangeEsp","Misc module",Category.MISC);}
}
