package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class Sky extends Module {
    public final BoolSetting stars=addBool("Stars","Show custom stars",true);
    public final SliderSetting starCount=addSlider("Star Count","Number of stars",1000,100,5000);
    public final BoolSetting twinkle=addBool("Twinkle","Stars twinkle",true);
    public final SliderSetting fogTint=addSlider("Fog Tint","Fog color intensity",50,0,100);
    public final BoolSetting particles=addBool("Particles","Sky particles",true);
    public final EnumSetting shape=addEnum("Shape","Particle shape","Motes","Motes","Stars","Circles");
    public final EnumSetting blend=addEnum("Blend","Blend mode","Glow","Glow","Additive","Normal");
    public final SliderSetting count=addSlider("Count","Particle count",1000,100,5000);
    public final SliderSetting radius=addSlider("Radius","Particle radius",12,1,50);
    public final SliderSetting size=addSlider("Size","Particle size",0.14,0.01,2);
    public Sky(){super("Sky","Custom sky with stars and particles",Category.VISUALS);}
}
