package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class Animations extends Module {
    public Animations(){super("Animations","Client module",Category.CLIENT);}
}
