package com.sofclient.modules.render;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
public class FullBright extends Module {
    private double orig=1.0;
    public FullBright(){super("FullBright","Renders everything at maximum brightness",Category.RENDER);}
    @Override public void onEnable(){MinecraftClient c=MinecraftClient.getInstance();orig=c.options.getGamma().getValue();c.options.getGamma().setValue(10.0);}
    @Override public void onDisable(){MinecraftClient.getInstance().options.getGamma().setValue(orig);}
}
