package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class SpawnerBeam extends Module {
    public SpawnerBeam(){super("SpawnerBeam","Render module",Category.RENDER);}
}
