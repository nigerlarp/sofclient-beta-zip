package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
public class TargetEsp extends Module {
    public final SliderSetting range=addSlider("Range","Highlight range",8,1,20);
    public TargetEsp(){super("Target ESP","Highlights your current target with an indicator",Category.VISUALS);}
    @Override public void onHudRender(DrawContext ctx){
        MinecraftClient c=MinecraftClient.getInstance();
        if(c.player==null||c.world==null)return;
        c.world.getPlayers().stream()
            .filter(p->p!=c.player&&p.isAlive()&&c.player.distanceTo(p)<=range.get())
            .min((a,b)->Double.compare(c.player.distanceTo(a),c.player.distanceTo(b)))
            .ifPresent(t->{
                String name=t.getName().getString();
                int hp=(int)t.getHealth();
                int x=c.getWindow().getScaledWidth()/2-30;
                int y=c.getWindow().getScaledHeight()/2+20;
                ctx.fill(x-2,y-2,x+120,y+30,0xAA000000);
                ctx.drawTextWithShadow(c.textRenderer,name,x,y,0xFFFF6EB4);
                ctx.drawTextWithShadow(c.textRenderer,"HP: "+hp,x,y+12,0xFFFFFFFF);
            });
    }
}
