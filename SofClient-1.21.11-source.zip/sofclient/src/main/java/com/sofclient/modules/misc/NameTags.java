package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class NameTags extends Module {
    public NameTags(){super("NameTags","Misc module",Category.MISC);}
}
