package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
public class Zoom extends Module {
    public final SliderSetting fov=addSlider("FOV","Zoomed FOV",10,1,30);
    private double origFov=70;
    public Zoom(){super("Zoom","Zoom like Optifine",Category.MISC);}
    @Override public void onEnable(){MinecraftClient c=MinecraftClient.getInstance();origFov=c.options.getFov().getValue();c.options.getFov().setValue((int)fov.get());}
    @Override public void onDisable(){MinecraftClient.getInstance().options.getFov().setValue((int)origFov);}
}
