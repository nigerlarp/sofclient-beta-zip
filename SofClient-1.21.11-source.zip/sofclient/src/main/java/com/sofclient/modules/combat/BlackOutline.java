package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class BlackOutline extends Module {
    public BlackOutline(){super("BlackOutline","Combat module: BlackOutline",Category.COMBAT);}
}
