package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FakePay extends Module {
    public FakePay(){super("FakePay","Misc module",Category.MISC);}
}
