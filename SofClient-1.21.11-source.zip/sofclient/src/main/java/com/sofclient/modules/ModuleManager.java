package com.sofclient.modules;

import com.sofclient.modules.combat.*;
import com.sofclient.modules.misc.*;
import com.sofclient.modules.render.*;
import com.sofclient.modules.visuals.*;
import com.sofclient.modules.client.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.*;
import java.util.stream.Collectors;

public class ModuleManager {

    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // ---- COMBAT ----
        register(new AutoTotem());
        register(new AutoCrystal());
        register(new AnchorMacro());
        register(new DoubleAnchor());
        register(new InvTotem());
        register(new AimAssist());
        register(new Hitbox());
        register(new TriggerBot());
        register(new CrystalOptimizer());
        register(new SosChunkFinder());
        register(new AutoHitCrystal());
        register(new NameProtect());
        register(new BlackOutline());
        register(new AspectRatio());
        register(new SosChunkV2());

        // ---- MISC ----
        register(new SignProtect());
        register(new NameProtectMisc());
        register(new FreeCam());
        register(new AutoTpa());
        register(new AutoClicker());
        register(new AutoTool());
        register(new FastUse());
        register(new NameTags());
        register(new FakePay());
        register(new WeatherNotifier());
        register(new FakeStats());
        register(new FakeLootDrop());
        register(new ArmorTracker());
        register(new CustomCrosshair());
        register(new StaffList());
        register(new CustomGlint());
        register(new CustomFov());
        register(new CoordSnapper());
        register(new AutoWalk());
        register(new Zoom());
        register(new FreeLook());
        register(new SpawnerProtect());
        register(new GamblerGrinder());
        register(new PanicOrder());
        register(new RelogMethod());
        register(new FakeName());
        register(new StrangeEsp());

        // ---- RENDER ----
        register(new BlockEsp());
        register(new StorageEsp());
        register(new BlockEntitiesEsp());
        register(new HoleEsp());
        register(new FullBright());
        register(new PlayerEsp());
        register(new MobEsp());
        register(new SpawnerNameTags());
        register(new SpawnerBeam());
        register(new ClusterEsp());
        register(new SusChunkFinder());
        register(new ChunkFinder());
        register(new RegionPvp());

        // ---- VISUALS ----
        register(new CustomBloom());
        register(new HitParticles());
        register(new TargetEsp());
        register(new Cosmetics());
        register(new Luma());
        register(new Aurora());
        register(new CrystalPulse());
        register(new MotionBlur());
        register(new Sky());

        // ---- CLIENT ----
        register(new Hud());
        register(new SpotifyHud());
        register(new ChatMacro());
        register(new ConfigShare());
        register(new Animations());
        register(new B73JumpCircles());
        register(new CreamyKeys());
        register(new ClickGui());
        register(new MusicHud());
        register(new FreeLoan());
    }

    private void register(Module m) { modules.add(m); }

    public void onTick(MinecraftClient client) {
        if (client.player == null) return;
        for (Module m : modules) if (m.isEnabled()) m.onTick(client);
    }

    public void onHudRender(DrawContext ctx) {
        for (Module m : modules) if (m.isEnabled()) m.onHudRender(ctx);
    }

    public List<Module> getAll() { return modules; }

    public List<Module> getByCategory(Module.Category cat) {
        return modules.stream().filter(m -> m.getCategory() == cat).collect(Collectors.toList());
    }

    public Module get(String name) {
        return modules.stream().filter(m -> m.getName().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    @SuppressWarnings("unchecked")
    public <T extends Module> T get(Class<T> clazz) {
        return (T) modules.stream().filter(m -> m.getClass() == clazz).findFirst().orElse(null);
    }
}
