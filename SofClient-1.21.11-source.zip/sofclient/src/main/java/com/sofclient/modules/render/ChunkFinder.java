package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class ChunkFinder extends Module {
    public ChunkFinder(){super("ChunkFinder","Render module",Category.RENDER);}
}
