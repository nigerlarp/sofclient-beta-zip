package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class HoleEsp extends Module {
    public HoleEsp(){super("HoleEsp","Render module",Category.RENDER);}
}
