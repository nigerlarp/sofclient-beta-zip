package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class WeatherNotifier extends Module {
    public WeatherNotifier(){super("WeatherNotifier","Misc module",Category.MISC);}
}
