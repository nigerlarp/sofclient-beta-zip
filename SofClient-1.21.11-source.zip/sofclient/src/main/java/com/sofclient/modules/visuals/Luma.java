package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class Luma extends Module {
    public Luma(){super("Luma","Visuals module",Category.VISUALS);}
}
