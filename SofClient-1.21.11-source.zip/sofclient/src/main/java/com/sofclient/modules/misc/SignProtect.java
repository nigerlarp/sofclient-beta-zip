package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class SignProtect extends Module {
    public SignProtect(){super("SignProtect","Misc module",Category.MISC);}
}
