package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class StorageEsp extends Module {
    public StorageEsp(){super("StorageEsp","Render module",Category.RENDER);}
}
