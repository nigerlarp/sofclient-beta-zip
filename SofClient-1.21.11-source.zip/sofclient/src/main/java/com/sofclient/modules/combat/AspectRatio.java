package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class AspectRatio extends Module {
    public AspectRatio(){super("AspectRatio","Combat module: AspectRatio",Category.COMBAT);}
}
