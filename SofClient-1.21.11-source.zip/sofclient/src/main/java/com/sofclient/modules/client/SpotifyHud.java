package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class SpotifyHud extends Module {
    public SpotifyHud(){super("SpotifyHud","Client module",Category.CLIENT);}
}
