package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class CoordSnapper extends Module {
    public CoordSnapper(){super("CoordSnapper","Misc module",Category.MISC);}
}
