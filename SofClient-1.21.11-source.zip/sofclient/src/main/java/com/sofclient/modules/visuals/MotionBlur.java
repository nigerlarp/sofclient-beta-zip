package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class MotionBlur extends Module {
    public MotionBlur(){super("MotionBlur","Visuals module",Category.VISUALS);}
}
