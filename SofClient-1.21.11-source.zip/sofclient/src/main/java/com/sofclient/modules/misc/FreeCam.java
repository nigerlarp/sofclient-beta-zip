package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FreeCam extends Module {
    public FreeCam(){super("FreeCam","Misc module",Category.MISC);}
}
