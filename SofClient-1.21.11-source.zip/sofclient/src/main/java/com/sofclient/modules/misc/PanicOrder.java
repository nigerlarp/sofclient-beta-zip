package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class PanicOrder extends Module {
    public PanicOrder(){super("PanicOrder","Misc module",Category.MISC);}
}
