package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class AutoTpa extends Module {
    public AutoTpa(){super("AutoTpa","Misc module",Category.MISC);}
}
