package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FakeStats extends Module {
    public FakeStats(){super("FakeStats","Misc module",Category.MISC);}
}
