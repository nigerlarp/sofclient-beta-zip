package com.sofclient.modules.client;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
public class Hud extends Module {
    public final BoolSetting coords=addBool("Coords","Show XYZ coordinates",true);
    public final BoolSetting ping=addBool("Ping","Show ping",true);
    public final BoolSetting fps=addBool("FPS","Show FPS",true);
    public final BoolSetting tps=addBool("TPS","Show server TPS",true);
    public final BoolSetting armor=addBool("Armor","Show armor durability",true);
    public Hud(){super("HUD","Customizable heads-up display",Category.CLIENT);}
    @Override public void onHudRender(DrawContext ctx){
        MinecraftClient c=MinecraftClient.getInstance();
        if(c.player==null)return;
        int x=4,y=4;
        if(fps.get()){ctx.drawTextWithShadow(c.textRenderer,"FPS: "+c.getCurrentFps(),x,y,0xFFFF6EB4);y+=10;}
        if(coords.get()){
            var p=c.player.getPos();
            ctx.drawTextWithShadow(c.textRenderer,String.format("XYZ: %.1f / %.1f / %.1f",p.x,p.y,p.z),x,y,0xFFFFFFFF);y+=10;
        }
        if(ping.get()&&c.getNetworkHandler()!=null&&c.player.networkHandler!=null){
            var entry=c.player.networkHandler.getPlayerListEntry(c.player.getUuid());
            if(entry!=null){ctx.drawTextWithShadow(c.textRenderer,"Ping: "+entry.getLatency()+"ms",x,y,0xFFFFFFFF);y+=10;}
        }
    }
}
