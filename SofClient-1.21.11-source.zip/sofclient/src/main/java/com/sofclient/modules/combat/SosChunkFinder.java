package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class SosChunkFinder extends Module {
    public SosChunkFinder(){super("SosChunkFinder","Combat module: SosChunkFinder",Category.COMBAT);}
}
