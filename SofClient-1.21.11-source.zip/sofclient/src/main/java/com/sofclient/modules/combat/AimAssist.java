package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
public class AimAssist extends Module {
    public final SliderSetting speed=addSlider("Speed","Smoothness",2.5,0.5,10);
    public final SliderSetting range=addSlider("Range","Target range",5,1,8);
    public final BoolSetting visCheck=addBool("Vis Check","Only visible targets",true);
    public AimAssist(){super("AimAssist","Legit aim assist — smooth, configurable",Category.COMBAT);}
    @Override public void onTick(MinecraftClient c){
        if(c.player==null||c.world==null)return;
        PlayerEntity t=c.world.getPlayers().stream()
            .filter(p->p!=c.player&&p.isAlive()&&c.player.distanceTo(p)<=range.get())
            .min((a,b)->Double.compare(c.player.distanceTo(a),c.player.distanceTo(b))).orElse(null);
        if(t==null)return;
        double dx=t.getX()-c.player.getX(),dy=t.getEyeY()-c.player.getEyeY(),dz=t.getZ()-c.player.getZ();
        double dist=Math.sqrt(dx*dx+dz*dz);
        float ty=(float)Math.toDegrees(Math.atan2(-dx,dz));
        float tp=(float)(-Math.toDegrees(Math.atan2(dy,dist)));
        float sp=(float)(speed.get()*0.5f);
        float yd=ty-c.player.getYaw(); while(yd>180)yd-=360; while(yd<-180)yd+=360;
        c.player.setYaw(c.player.getYaw()+Math.max(-sp,Math.min(sp,yd)));
        c.player.setPitch(c.player.getPitch()+Math.max(-sp,Math.min(sp,tp-c.player.getPitch())));
    }
}
