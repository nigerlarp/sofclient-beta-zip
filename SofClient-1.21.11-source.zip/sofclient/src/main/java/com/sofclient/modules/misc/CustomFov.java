package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class CustomFov extends Module {
    public CustomFov(){super("CustomFov","Misc module",Category.MISC);}
}
