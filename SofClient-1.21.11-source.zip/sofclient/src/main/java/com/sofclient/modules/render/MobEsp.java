package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class MobEsp extends Module {
    public MobEsp(){super("MobEsp","Render module",Category.RENDER);}
}
