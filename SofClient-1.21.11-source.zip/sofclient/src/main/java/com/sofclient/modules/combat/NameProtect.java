package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class NameProtect extends Module {
    public NameProtect(){super("NameProtect","Combat module: NameProtect",Category.COMBAT);}
}
