package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class InvTotem extends Module {
    public InvTotem(){super("InvTotem","Combat module: InvTotem",Category.COMBAT);}
}
