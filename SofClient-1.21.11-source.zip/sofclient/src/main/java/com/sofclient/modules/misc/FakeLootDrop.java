package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FakeLootDrop extends Module {
    public FakeLootDrop(){super("FakeLootDrop","Misc module",Category.MISC);}
}
