package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class GamblerGrinder extends Module {
    public GamblerGrinder(){super("GamblerGrinder","Misc module",Category.MISC);}
}
