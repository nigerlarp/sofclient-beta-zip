package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
public class TriggerBot extends Module {
    public final SliderSetting delay=addSlider("Delay","Ticks before attacking",2,0,10);
    private int t=0;
    public TriggerBot(){super("TriggerBot","Automatically attacks when crosshair is on a player",Category.COMBAT);}
    @Override public void onTick(MinecraftClient c){
        if(c.player==null||c.crosshairTarget==null){t=0;return;}
        if(c.crosshairTarget instanceof EntityHitResult ehr&&ehr.getEntity() instanceof PlayerEntity target){
            if(t++>=(int)delay.get()&&c.player.getAttackCooldownProgress(0)>=1f){
                c.interactionManager.attackEntity(c.player,target);
                c.player.swingHand(Hand.MAIN_HAND); t=0;
            }
        } else t=0;
    }
}
