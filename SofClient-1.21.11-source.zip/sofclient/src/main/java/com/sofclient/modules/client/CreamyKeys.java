package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class CreamyKeys extends Module {
    public CreamyKeys(){super("CreamyKeys","Client module",Category.CLIENT);}
}
