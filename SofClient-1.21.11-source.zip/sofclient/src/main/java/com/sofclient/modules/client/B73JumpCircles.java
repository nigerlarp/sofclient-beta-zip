package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class B73JumpCircles extends Module {
    public B73JumpCircles(){super("B73JumpCircles","Client module",Category.CLIENT);}
}
