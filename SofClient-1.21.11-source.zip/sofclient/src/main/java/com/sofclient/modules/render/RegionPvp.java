package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class RegionPvp extends Module {
    public RegionPvp(){super("RegionPvp","Render module",Category.RENDER);}
}
