package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class Cosmetics extends Module {
    public final BoolSetting wings=addBool("Wings","Show cosmetic wings",false);
    public final EnumSetting wingStyle=addEnum("Wing Style","Wing appearance","Seraph","Seraph","Dragon","Angel","Butterfly","Bat");
    public final SliderSetting wingScale=addSlider("Wing Scale","Size of wings",100,50,200);
    public final BoolSetting wingJewels=addBool("Wing Jewels","Glowing jewels on wings",true);
    public final BoolSetting hideElytra=addBool("Hide Elytra","Hide vanilla elytra",false);
    public final BoolSetting crown=addBool("Crown","Show cosmetic crown",false);
    public final EnumSetting crownStyle=addEnum("Crown Style","Crown type","Gold","Gold","Diamond","Gem","Dark");
    public final BoolSetting miniYou=addBool("Mini You","Tiny player following you",false);
    public Cosmetics(){super("Cosmetics","3D feather wings, gemstone crowns & more",Category.VISUALS);}
}
