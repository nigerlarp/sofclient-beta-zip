package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class ConfigShare extends Module {
    public ConfigShare(){super("ConfigShare","Client module",Category.CLIENT);}
}
