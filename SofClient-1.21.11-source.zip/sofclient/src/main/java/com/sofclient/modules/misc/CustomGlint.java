package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class CustomGlint extends Module {
    public CustomGlint(){super("CustomGlint","Misc module",Category.MISC);}
}
