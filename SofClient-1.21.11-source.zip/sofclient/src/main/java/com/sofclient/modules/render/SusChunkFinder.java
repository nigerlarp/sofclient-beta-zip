package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class SusChunkFinder extends Module {
    public SusChunkFinder(){super("SusChunkFinder","Render module",Category.RENDER);}
}
