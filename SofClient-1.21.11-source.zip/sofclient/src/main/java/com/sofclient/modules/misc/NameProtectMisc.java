package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class NameProtectMisc extends Module {
    public NameProtectMisc(){super("NameProtectMisc","Misc module",Category.MISC);}
}
