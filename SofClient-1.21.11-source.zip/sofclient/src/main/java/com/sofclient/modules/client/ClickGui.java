package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class ClickGui extends Module {
    public final EnumSetting style=addEnum("Style","GUI Style","PANEL","PANEL","DROPDOWN");
    public final SliderSetting blur=addSlider("Background Blur","Backdrop blur amount",2,0,10);
    public final SliderSetting dim=addSlider("Backdrop Dim","Background dim %",40,0,100);
    public final SliderSetting scale=addSlider("Menu Scale","GUI scale %",85,50,150);
    public final BoolSetting animations=addBool("Animations","Smooth open/close",true);
    public final BoolSetting tooltips=addBool("Tooltips","Show module tooltips",true);
    public final BoolSetting shadow=addBool("Window Shadow","Window drop shadows",true);
    public ClickGui(){super("ClickGUI","Configure the client GUI style",Category.CLIENT);}
}
