package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class ClusterEsp extends Module {
    public ClusterEsp(){super("ClusterEsp","Render module",Category.RENDER);}
}
