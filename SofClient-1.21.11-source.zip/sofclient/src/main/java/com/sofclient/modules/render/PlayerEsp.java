package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class PlayerEsp extends Module {
    public PlayerEsp(){super("PlayerEsp","Render module",Category.RENDER);}
}
