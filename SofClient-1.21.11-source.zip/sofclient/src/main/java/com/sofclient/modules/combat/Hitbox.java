package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class Hitbox extends Module {
    public Hitbox(){super("Hitbox","Combat module: Hitbox",Category.COMBAT);}
}
