package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class DoubleAnchor extends Module {
    public DoubleAnchor(){super("DoubleAnchor","Combat module: DoubleAnchor",Category.COMBAT);}
}
