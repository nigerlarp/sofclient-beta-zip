package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class HitParticles extends Module {
    public HitParticles(){super("HitParticles","Visuals module",Category.VISUALS);}
}
