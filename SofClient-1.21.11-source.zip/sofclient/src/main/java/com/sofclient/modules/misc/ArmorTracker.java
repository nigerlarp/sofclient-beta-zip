package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class ArmorTracker extends Module {
    public ArmorTracker(){super("ArmorTracker","Misc module",Category.MISC);}
}
