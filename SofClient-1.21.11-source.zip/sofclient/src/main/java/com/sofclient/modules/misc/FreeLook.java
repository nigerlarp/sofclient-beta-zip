package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FreeLook extends Module {
    public FreeLook(){super("FreeLook","Misc module",Category.MISC);}
}
