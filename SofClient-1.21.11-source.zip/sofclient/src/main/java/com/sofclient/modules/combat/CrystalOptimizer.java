package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class CrystalOptimizer extends Module {
    public CrystalOptimizer(){super("CrystalOptimizer","Combat module: CrystalOptimizer",Category.COMBAT);}
}
