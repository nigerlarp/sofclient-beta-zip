package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class StaffList extends Module {
    public StaffList(){super("StaffList","Misc module",Category.MISC);}
}
