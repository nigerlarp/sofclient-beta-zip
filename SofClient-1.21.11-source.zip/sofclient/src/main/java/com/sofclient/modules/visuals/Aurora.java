package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class Aurora extends Module {
    public Aurora(){super("Aurora","Visuals module",Category.VISUALS);}
}
