package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class AutoHitCrystal extends Module {
    public AutoHitCrystal(){super("AutoHitCrystal","Combat module: AutoHitCrystal",Category.COMBAT);}
}
