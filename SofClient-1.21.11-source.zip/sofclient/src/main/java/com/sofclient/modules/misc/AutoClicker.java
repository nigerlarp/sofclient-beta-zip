package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
public class AutoClicker extends Module {
    public final SliderSetting cps=addSlider("CPS","Clicks per second",12,1,20);
    private int t=0;
    public AutoClicker(){super("AutoClicker","Auto-clicks at configurable CPS",Category.MISC);}
    @Override public void onTick(MinecraftClient c){
        if(c.player==null)return;
        int tpc=(int)(20.0/cps.get());
        if(++t>=tpc){t=0;if(c.options.attackKey.isPressed())c.player.swingHand(Hand.MAIN_HAND);}
    }
}
