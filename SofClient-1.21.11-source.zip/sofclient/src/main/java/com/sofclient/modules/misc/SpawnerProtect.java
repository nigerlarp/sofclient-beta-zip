package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class SpawnerProtect extends Module {
    public SpawnerProtect(){super("SpawnerProtect","Misc module",Category.MISC);}
}
