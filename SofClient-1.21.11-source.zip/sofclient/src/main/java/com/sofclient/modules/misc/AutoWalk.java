package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class AutoWalk extends Module {
    public AutoWalk(){super("AutoWalk","Misc module",Category.MISC);}
}
