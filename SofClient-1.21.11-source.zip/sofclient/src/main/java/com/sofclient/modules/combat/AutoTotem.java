package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
public class AutoTotem extends Module {
    public final SliderSetting health = addSlider("Health Threshold","Re-equip below this HP",10,1,20);
    public AutoTotem(){super("Auto Totem","Refills offhand with totems automatically",Category.COMBAT);}
    @Override public void onTick(MinecraftClient c){
        if(c.player==null||c.interactionManager==null)return;
        if(c.player.getOffHandStack().getItem()!=Items.TOTEM_OF_UNDYING){
            var inv=c.player.getInventory();
            for(int i=0;i<inv.size();i++){
                if(inv.getStack(i).getItem()==Items.TOTEM_OF_UNDYING){
                    c.interactionManager.clickSlot(c.player.playerScreenHandler.syncId,i,45,SlotActionType.SWAP,c.player);
                    break;
                }
            }
        }
    }
}
