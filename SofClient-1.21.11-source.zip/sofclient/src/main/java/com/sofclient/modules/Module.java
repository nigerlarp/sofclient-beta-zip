package com.sofclient.modules;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {

    public enum Category {
        COMBAT("Combat", "\u2694"),
        MISC("Misc", "\u2699"),
        RENDER("Render", "\u25A1"),
        VISUALS("Visuals", "\u2665"),
        CLIENT("Client", ">");

        public final String name;
        public final String icon;
        Category(String name, String icon) { this.name = name; this.icon = icon; }
    }

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled = false;
    private int keybind = -1;
    protected final List<Setting<?>> settings = new ArrayList<>();

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void onTick(MinecraftClient client) {}
    public void onHudRender(DrawContext ctx) {}
    public void onEnable() {}
    public void onDisable() {}
    public void onWorldRender(float tickDelta) {}

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable(); else onDisable();
    }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean v) { if (v != enabled) toggle(); }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public Category getCategory() { return category; }
    public int getKeybind() { return keybind; }
    public void setKeybind(int key) { this.keybind = key; }
    public List<Setting<?>> getSettings() { return settings; }

    protected BoolSetting addBool(String name, String desc, boolean def) {
        BoolSetting s = new BoolSetting(name, desc, def);
        settings.add(s); return s;
    }
    protected SliderSetting addSlider(String name, String desc, double def, double min, double max) {
        SliderSetting s = new SliderSetting(name, desc, def, min, max);
        settings.add(s); return s;
    }
    protected EnumSetting addEnum(String name, String desc, String def, String... opts) {
        EnumSetting s = new EnumSetting(name, desc, def, opts);
        settings.add(s); return s;
    }

    // ---- Setting types ----
    public abstract static class Setting<T> {
        public final String name, description;
        protected T value;
        public Setting(String name, String description, T def) {
            this.name = name; this.description = description; this.value = def;
        }
        public T get() { return value; }
        public void set(T v) { this.value = v; }
    }

    public static class BoolSetting extends Setting<Boolean> {
        public BoolSetting(String n, String d, boolean def) { super(n, d, def); }
        public void toggle() { value = !value; }
    }

    public static class SliderSetting extends Setting<Double> {
        public final double min, max;
        public SliderSetting(String n, String d, double def, double min, double max) {
            super(n, d, def); this.min = min; this.max = max;
        }
    }

    public static class EnumSetting extends Setting<String> {
        public final String[] options;
        public EnumSetting(String n, String d, String def, String... opts) {
            super(n, d, def); this.options = opts;
        }
        public void cycle() {
            for (int i = 0; i < options.length; i++) {
                if (options[i].equals(value)) { value = options[(i+1) % options.length]; return; }
            }
        }
    }
}
