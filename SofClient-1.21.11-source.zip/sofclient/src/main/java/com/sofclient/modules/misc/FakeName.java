package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class FakeName extends Module {
    public FakeName(){super("FakeName","Misc module",Category.MISC);}
}
