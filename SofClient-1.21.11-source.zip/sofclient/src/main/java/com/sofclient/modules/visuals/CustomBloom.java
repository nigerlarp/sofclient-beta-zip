package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class CustomBloom extends Module {
    public CustomBloom(){super("CustomBloom","Visuals module",Category.VISUALS);}
}
