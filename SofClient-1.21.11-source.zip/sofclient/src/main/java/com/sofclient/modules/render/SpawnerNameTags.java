package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class SpawnerNameTags extends Module {
    public SpawnerNameTags(){super("SpawnerNameTags","Render module",Category.RENDER);}
}
