package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class RelogMethod extends Module {
    public RelogMethod(){super("RelogMethod","Misc module",Category.MISC);}
}
