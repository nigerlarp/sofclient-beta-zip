package com.sofclient.modules.render;
import com.sofclient.modules.Module;
public class BlockEntitiesEsp extends Module {
    public BlockEntitiesEsp(){super("BlockEntitiesEsp","Render module",Category.RENDER);}
}
