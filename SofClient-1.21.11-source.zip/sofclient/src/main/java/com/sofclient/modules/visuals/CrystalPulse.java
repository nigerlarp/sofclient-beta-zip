package com.sofclient.modules.visuals;
import com.sofclient.modules.Module;
public class CrystalPulse extends Module {
    public CrystalPulse(){super("CrystalPulse","Visuals module",Category.VISUALS);}
}
