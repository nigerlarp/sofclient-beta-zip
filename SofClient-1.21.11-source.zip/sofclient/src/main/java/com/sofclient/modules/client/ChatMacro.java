package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class ChatMacro extends Module {
    public ChatMacro(){super("ChatMacro","Client module",Category.CLIENT);}
}
