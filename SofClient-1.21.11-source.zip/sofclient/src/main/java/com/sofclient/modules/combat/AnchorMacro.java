package com.sofclient.modules.combat;
import com.sofclient.modules.Module;
public class AnchorMacro extends Module {
    public AnchorMacro(){super("AnchorMacro","Combat module: AnchorMacro",Category.COMBAT);}
}
