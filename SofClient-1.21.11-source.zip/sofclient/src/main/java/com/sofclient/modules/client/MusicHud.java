package com.sofclient.modules.client;
import com.sofclient.modules.Module;
public class MusicHud extends Module {
    public MusicHud(){super("MusicHud","Client module",Category.CLIENT);}
}
