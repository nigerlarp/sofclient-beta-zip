package com.sofclient.modules.misc;
import com.sofclient.modules.Module;
public class CustomCrosshair extends Module {
    public CustomCrosshair(){super("CustomCrosshair","Misc module",Category.MISC);}
}
