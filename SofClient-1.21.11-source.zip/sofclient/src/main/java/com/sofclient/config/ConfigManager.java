package com.sofclient.config;

import com.sofclient.SofClient;
import com.sofclient.modules.Module;
import com.sofclient.theme.ThemeManager;
import net.minecraft.client.MinecraftClient;

import java.io.*;
import java.nio.file.*;
import java.util.Properties;

public class ConfigManager {

    private final Path configDir;
    private final Path mainConfig;
    private Properties props = new Properties();

    public ConfigManager() {
        configDir = MinecraftClient.getInstance().runDirectory.toPath().resolve("sofclient");
        mainConfig = configDir.resolve("config.properties");
        try {
            Files.createDirectories(configDir);
            if (Files.exists(mainConfig)) {
                try (InputStream in = Files.newInputStream(mainConfig)) {
                    props.load(in);
                }
            }
        } catch (Exception e) {
            SofClient.LOGGER.error("Failed to load config", e);
        }
    }

    public boolean isFirstLaunch() {
        return !props.containsKey("profileName");
    }

    public String getProfileName() {
        return props.getProperty("profileName", "SofClient");
    }

    public void setProfileName(String name) {
        props.setProperty("profileName", name);
        save();
    }

    public String getGuiStyle() {
        return props.getProperty("guiStyle", "PANEL");
    }

    public void setGuiStyle(String style) {
        props.setProperty("guiStyle", style);
        save();
    }

    public String getTheme() {
        return props.getProperty("theme", "DEFAULT");
    }

    public void setTheme(String theme) {
        props.setProperty("theme", theme);
        save();
    }

    public void saveModuleStates() {
        if (SofClient.moduleManager == null) return;
        for (Module m : SofClient.moduleManager.getAll()) {
            props.setProperty("module." + m.getName(), String.valueOf(m.isEnabled()));
        }
        save();
    }

    public void loadModuleStates() {
        if (SofClient.moduleManager == null) return;
        for (Module m : SofClient.moduleManager.getAll()) {
            String key = "module." + m.getName();
            if (props.containsKey(key)) {
                boolean enabled = Boolean.parseBoolean(props.getProperty(key));
                m.setEnabled(enabled);
            }
        }
    }

    public void applyTheme() {
        if (SofClient.themeManager == null) return;
        try {
            String t = getTheme();
            SofClient.themeManager.setCurrent(ThemeManager.Theme.valueOf(t));
        } catch (Exception ignored) {}
    }

    private void save() {
        try (OutputStream out = Files.newOutputStream(mainConfig)) {
            props.store(out, "SofClient Configuration");
        } catch (Exception e) {
            SofClient.LOGGER.error("Failed to save config", e);
        }
    }
}
