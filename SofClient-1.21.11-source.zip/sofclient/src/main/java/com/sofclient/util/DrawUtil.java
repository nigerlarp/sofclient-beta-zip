package com.sofclient.util;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

public class DrawUtil {

    /** Rounded rectangle fill */
    public static void fillRounded(DrawContext ctx, int x, int y, int w, int h, int radius, int color) {
        // Draw center cross
        ctx.fill(x + radius, y, x + w - radius, y + h, color);
        ctx.fill(x, y + radius, x + radius, y + h - radius, color);
        ctx.fill(x + w - radius, y + radius, x + w, y + h - radius, color);
        // Draw corner circles
        fillCircleQuadrant(ctx, x + radius, y + radius, radius, 2, color);
        fillCircleQuadrant(ctx, x + w - radius, y + radius, radius, 1, color);
        fillCircleQuadrant(ctx, x + radius, y + h - radius, radius, 3, color);
        fillCircleQuadrant(ctx, x + w - radius, y + h - radius, radius, 0, color);
    }

    private static void fillCircleQuadrant(DrawContext ctx, int cx, int cy, int r, int quadrant, int color) {
        for (int px = 0; px <= r; px++) {
            for (int py = 0; py <= r; py++) {
                if (px * px + py * py <= r * r) {
                    int dx = quadrant == 1 || quadrant == 0 ? px : -px;
                    int dy = quadrant == 2 || quadrant == 1 ? -py : py;
                    ctx.fill(cx + dx, cy + dy, cx + dx + 1, cy + dy + 1, color);
                }
            }
        }
    }

    /** Rounded rectangle outline */
    public static void outlineRounded(DrawContext ctx, int x, int y, int w, int h, int radius, int thickness, int color) {
        // Simple border approximation
        ctx.fill(x + radius, y, x + w - radius, y + thickness, color);
        ctx.fill(x + radius, y + h - thickness, x + w - radius, y + h, color);
        ctx.fill(x, y + radius, x + thickness, y + h - radius, color);
        ctx.fill(x + w - thickness, y + radius, x + w, y + h - radius, color);
    }

    /** Draw a toggle switch */
    public static void drawToggle(DrawContext ctx, int x, int y, boolean on, int accentColor) {
        int trackW = 24, trackH = 12, radius = 6;
        int trackColor = on ? (accentColor & 0x00FFFFFF | 0xCC000000) : 0xCC2A2A3A;
        int knobColor = on ? accentColor : 0xFF666677;
        // Track
        fillRounded(ctx, x, y, trackW, trackH, radius, trackColor);
        // Knob
        int knobX = on ? x + trackW - trackH + 2 : x + 2;
        fillRounded(ctx, knobX, y + 2, trackH - 4, trackH - 4, (trackH - 4) / 2, knobColor);
    }

    /** Draw a slider */
    public static void drawSlider(DrawContext ctx, int x, int y, int w, double value, double min, double max, int accentColor) {
        int h = 4;
        int trackColor = 0xFF2A2A3A;
        ctx.fill(x, y, x + w, y + h, trackColor);
        float pct = (float) ((value - min) / (max - min));
        ctx.fill(x, y, x + (int) (w * pct), y + h, accentColor);
        // Knob
        int kx = x + (int) (w * pct) - 4;
        fillRounded(ctx, kx, y - 3, 8, 10, 4, 0xFFFFFFFF);
    }

    /** Gradient fill top-to-bottom */
    public static void fillGradient(DrawContext ctx, int x, int y, int w, int h, int colorTop, int colorBottom) {
        ctx.fillGradient(x, y, x + w, y + h, colorTop, colorBottom);
    }

    /** Alpha blend two colors */
    public static int blend(int c1, int c2, float t) {
        int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF, b1 = c1 & 0xFF;
        int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF, b2 = c2 & 0xFF;
        return ((int)(a1 + (a2 - a1) * t) << 24) | ((int)(r1 + (r2 - r1) * t) << 16)
             | ((int)(g1 + (g2 - g1) * t) << 8) | (int)(b1 + (b2 - b1) * t);
    }
}
