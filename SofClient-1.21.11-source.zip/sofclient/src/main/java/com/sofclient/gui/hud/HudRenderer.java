package com.sofclient.gui.hud;

import com.sofclient.SofClient;
import com.sofclient.modules.Module;
import com.sofclient.util.DrawUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.List;
import java.util.stream.Collectors;

public class HudRenderer {

    public void render(DrawContext ctx, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        SofClient.themeManager.tick();
        SofClient.moduleManager.onHudRender(ctx);

        renderArrayList(ctx, mc);
    }

    /** Right-side arraylist of active modules */
    private void renderArrayList(DrawContext ctx, MinecraftClient mc) {
        List<Module> active = SofClient.moduleManager.getAll().stream()
            .filter(Module::isEnabled)
            .sorted((a, b) -> mc.textRenderer.getWidth(b.getName()) - mc.textRenderer.getWidth(a.getName()))
            .collect(Collectors.toList());

        if (active.isEmpty()) return;

        int screenW = mc.getWindow().getScaledWidth();
        int y = 2;
        int total = active.size();

        for (int i = 0; i < active.size(); i++) {
            Module m = active.get(i);
            int accent = SofClient.themeManager.getCurrent() == com.sofclient.theme.ThemeManager.Theme.RAINBOW
                ? SofClient.themeManager.getRainbowForIndex(i, total)
                : SofClient.themeManager.getAccentColor();

            String name = m.getName();
            int textW = mc.textRenderer.getWidth(name);
            int x = screenW - textW - 6;

            // Background bar
            ctx.fill(x - 2, y, screenW, y + 10, 0x66000000);
            // Accent left border
            ctx.fill(x - 2, y, x - 1, y + 10, accent);
            // Text
            ctx.drawTextWithShadow(mc.textRenderer, name, x, y + 1, accent);

            y += 11;
        }
    }
}
