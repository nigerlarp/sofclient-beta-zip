package com.sofclient.gui.welcome;

import com.sofclient.SofClient;
import com.sofclient.util.DrawUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class WelcomeScreen extends Screen {

    private String selectedLayout = "PANEL"; // PANEL or DROPDOWN
    private TextFieldWidget nameField;
    private float animProgress = 0f;
    private float pulse = 0f;

    // Card dimensions
    private int cardX, cardY, cardW = 700, cardH = 420;

    public WelcomeScreen() {
        super(Text.literal("SofClient - Welcome"));
    }

    @Override
    protected void init() {
        cardX = (width - cardW) / 2;
        cardY = (height - cardH) / 2;

        nameField = new TextFieldWidget(textRenderer,
            cardX + 370, cardY + 185, 290, 24, Text.literal(""));
        nameField.setMaxLength(24);
        nameField.setText("SofClient");
        nameField.setPlaceholder(Text.literal("Your name"));
        nameField.setDrawsBackground(false);
        addDrawableChild(nameField);
    }

    @Override
    public void tick() {
        animProgress = Math.min(1f, animProgress + 0.05f);
        pulse = (pulse + 0.03f) % (float)(Math.PI * 2);
        SofClient.themeManager.tick();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        // Dark fullscreen background
        ctx.fill(0, 0, width, height, 0xFF080810);

        // Animated particles in background
        renderBgParticles(ctx);

        int alpha = (int)(animProgress * 255);
        int baseAlpha = (alpha << 24) & 0xFF000000;

        // Card shadow
        DrawUtil.fillRounded(ctx, cardX + 6, cardY + 6, cardW, cardH, 16, 0x44000000);

        // Card background
        DrawUtil.fillRounded(ctx, cardX, cardY, cardW, cardH, 16, 0xF0101018);

        // Left panel (branding)
        int leftW = 310;
        DrawUtil.fillRounded(ctx, cardX, cardY, leftW, cardH, 16, 0xF0141420);
        // Right side is lighter
        ctx.fill(cardX + leftW, cardY, cardX + cardW, cardY + cardH, 0xF0101018);
        // Fix overlap at junction
        ctx.fill(cardX + leftW - 16, cardY, cardX + leftW, cardY + cardH, 0xF0141420);

        // Top-left: "SOFCLIENT" label
        ctx.drawTextWithShadow(textRenderer, "SOFCLIENT", cardX + 24, cardY + 22, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "BUILT AROUND YOU.", cardX + 24, cardY + 34, 0xFF888888);

        // Giant "SOF" number display
        int accent = SofClient.themeManager.getAccentColor();
        renderBigLogo(ctx, cardX + 60, cardY + 90, accent);

        // Bottom-left taglines
        ctx.drawTextWithShadow(textRenderer, "YOUR CLIENT.", cardX + 24, cardY + 330, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "YOUR RULES.", cardX + 24, cardY + 344, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "A SPACE THAT FEELS LIKE YOU.", cardX + 24, cardY + 362, 0xFF888888);

        // Pink accent line bottom-left
        ctx.fill(cardX + 24, cardY + 322, cardX + 50, cardY + 325, accent);

        // ---- Right side ----
        ctx.drawTextWithShadow(textRenderer, "WELCOME TO SOFCLIENT", cardX + 360, cardY + 30, accent);

        // Big title
        renderBigText(ctx, "MAKE IT YOURS.", cardX + 355, cardY + 55, 0xFFFFFFFF);

        ctx.drawTextWithShadow(textRenderer, "CHOOSE A NAME. PICK YOUR LAYOUT.", cardX + 358, cardY + 110, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "SETTLE IN AND MAKE YOURSELF AT HOME.", cardX + 358, cardY + 122, 0xFF888888);

        // Name field label
        ctx.drawTextWithShadow(textRenderer, "YOUR NAME", cardX + 358, cardY + 162, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "JUST FOR THIS CLIENT", cardX + 560, cardY + 162, 0xFF666666);

        // Name field box
        int fBgColor = nameField.isFocused() ? 0xFF1A1A2A : 0xFF131320;
        DrawUtil.fillRounded(ctx, cardX + 356, cardY + 180, 294, 28, 4, fBgColor);
        DrawUtil.outlineRounded(ctx, cardX + 356, cardY + 180, 294, 28, 4, 1,
            nameField.isFocused() ? accent : 0x44FFFFFF);

        // Layout label
        ctx.drawTextWithShadow(textRenderer, "YOUR LAYOUT", cardX + 358, cardY + 228, 0xFFCCCCCC);

        // PANEL button
        boolean panelSel = "PANEL".equals(selectedLayout);
        int panelBg = panelSel ? (accent & 0x00FFFFFF | 0x33000000) : 0xFF131320;
        int panelBorder = panelSel ? accent : 0x33FFFFFF;
        DrawUtil.fillRounded(ctx, cardX + 356, cardY + 246, 136, 60, 8, panelBg);
        DrawUtil.outlineRounded(ctx, cardX + 356, cardY + 246, 136, 60, 8, panelSel ? 2 : 1, panelBorder);
        ctx.drawTextWithShadow(textRenderer, "PANEL", cardX + 376, cardY + 258, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "ONE WORKSPACE", cardX + 376, cardY + 272, 0xFF888888);
        if (panelSel) ctx.fill(cardX + 476, cardY + 250, cardX + 482, cardY + 256, accent); // dot

        // DROPDOWN button
        boolean dropSel = "DROPDOWN".equals(selectedLayout);
        int dropBg = dropSel ? (accent & 0x00FFFFFF | 0x33000000) : 0xFF131320;
        int dropBorder = dropSel ? accent : 0x33FFFFFF;
        DrawUtil.fillRounded(ctx, cardX + 502, cardY + 246, 148, 60, 8, dropBg);
        DrawUtil.outlineRounded(ctx, cardX + 502, cardY + 246, 148, 60, 8, dropSel ? 2 : 1, dropBorder);
        ctx.drawTextWithShadow(textRenderer, "DROPDOWN", cardX + 522, cardY + 258, 0xFFFFFFFF);
        ctx.drawTextWithShadow(textRenderer, "CATEGORY PANELS", cardX + 522, cardY + 272, 0xFF888888);

        // CONTINUE button
        int btnColor = isNameValid() ? accent : 0xFF333344;
        DrawUtil.fillRounded(ctx, cardX + 356, cardY + 322, 294, 32, 6, btnColor);
        String btnText = isNameValid() ? "CONTINUE \u2192" : "CONTINUE \u2192";
        ctx.drawCenteredTextWithShadow(textRenderer, btnText, cardX + 356 + 147, cardY + 334, isNameValid() ? 0xFF000000 : 0xFF666666);

        // MAYBE LATER / SOUND ON
        DrawUtil.fillRounded(ctx, cardX + 356, cardY + 365, 136, 24, 4, 0xFF1A1A2A);
        DrawUtil.outlineRounded(ctx, cardX + 356, cardY + 365, 136, 24, 4, 1, 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "MAYBE LATER", cardX + 356 + 68, cardY + 372, 0xFFAAAAAA);

        DrawUtil.fillRounded(ctx, cardX + 502, cardY + 365, 148, 24, 4, 0xFF1A1A2A);
        DrawUtil.outlineRounded(ctx, cardX + 502, cardY + 365, 148, 24, 4, 1, 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "SOUND ON", cardX + 502 + 74, cardY + 372, 0xFFAAAAAA);

        super.render(ctx, mx, my, delta);
    }

    private void renderBigLogo(DrawContext ctx, int x, int y, int accent) {
        // Simple large "SOF" letters using scaled text
        MatrixStack stack = ctx.getMatrices();
        stack.push();
        stack.translate(x, y, 0);
        stack.scale(5f, 5f, 1f);
        ctx.drawTextWithShadow(textRenderer, "SOF", 0, 0, 0xFFCCCCCC);
        stack.pop();
        // Accent underline
        ctx.fill(x, y + 85, x + 190, y + 89, accent);
    }

    private void renderBigText(DrawContext ctx, String text, int x, int y, int color) {
        MatrixStack stack = ctx.getMatrices();
        stack.push();
        stack.translate(x, y, 0);
        stack.scale(2.2f, 2.2f, 1f);
        ctx.drawTextWithShadow(textRenderer, text, 0, 0, color);
        stack.pop();
    }

    private void renderBgParticles(DrawContext ctx) {
        // Simple static star-like dots
        int[] xs = {50, 120, 300, 450, 600, 750, 900, 100, 850, 400};
        int[] ys = {30, 150, 80, 200, 50, 180, 90, 300, 320, 400};
        int accent = SofClient.themeManager.getAccentColor();
        float pulseVal = (float)(Math.sin(pulse) * 0.5 + 0.5);
        for (int i = 0; i < xs.length; i++) {
            int alpha = (int)(80 + 60 * pulseVal);
            int c = (alpha << 24) | (accent & 0x00FFFFFF);
            ctx.fill(xs[i], ys[i], xs[i] + 2, ys[i] + 2, c);
        }
    }

    private boolean isNameValid() {
        String name = nameField.getText().trim();
        return name.length() >= 3 && name.length() <= 24;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Layout buttons
        if (mx >= cardX + 356 && mx <= cardX + 492 && my >= cardY + 246 && my <= cardY + 306) {
            selectedLayout = "PANEL";
            return true;
        }
        if (mx >= cardX + 502 && mx <= cardX + 650 && my >= cardY + 246 && my <= cardY + 306) {
            selectedLayout = "DROPDOWN";
            return true;
        }
        // Continue button
        if (mx >= cardX + 356 && mx <= cardX + 650 && my >= cardY + 322 && my <= cardY + 354) {
            if (isNameValid()) onContinue();
            return true;
        }
        // Maybe later
        if (mx >= cardX + 356 && mx <= cardX + 492 && my >= cardY + 365 && my <= cardY + 389) {
            onContinue(); // skip setup
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void onContinue() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) name = "SofClient";
        SofClient.configManager.setProfileName(name);
        SofClient.configManager.setGuiStyle(selectedLayout);
        client.setScreen(null);
    }

    @Override
    public boolean shouldPause() { return false; }
}
