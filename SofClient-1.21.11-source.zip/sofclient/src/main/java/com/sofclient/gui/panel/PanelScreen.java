package com.sofclient.gui.panel;

import com.sofclient.SofClient;
import com.sofclient.modules.Module;
import com.sofclient.util.DrawUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class PanelScreen extends Screen {

    private static final int PANEL_W = 160;
    private static final int PANEL_H_MAX = 400;
    private static final int HEADER_H = 24;
    private static final int ITEM_H = 22;
    private static final int PANEL_GAP = 8;

    // Currently open settings panel
    private Module selectedModule = null;
    private float animProgress = 1f;

    private TextFieldWidget searchField;
    private String searchQuery = "";

    // Panel positions (draggable in future)
    private final int[] panelXs = {10, 180, 350, 520, 690, 860};
    private final Module.Category[] cats = Module.Category.values();

    // Active tab for bottom bar
    private String activeTab = "MODULES";

    public PanelScreen() {
        super(Text.literal("SofClient"));
    }

    @Override
    protected void init() {
        searchField = new TextFieldWidget(textRenderer, width / 2 - 100, 10, 200, 18, Text.literal(""));
        searchField.setMaxLength(50);
        searchField.setPlaceholder(Text.literal("Search modules..."));
        searchField.setDrawsBackground(false);
        addDrawableChild(searchField);
    }

    @Override
    public void tick() {
        SofClient.themeManager.tick();
        searchQuery = searchField.getText().toLowerCase();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        int accent = SofClient.themeManager.getAccentColor();

        // Blurred/darkened backdrop
        ctx.fill(0, 0, width, height, 0xBB080810);

        // Top bar
        renderTopBar(ctx, mx, my, accent);

        // Module panels per category (skip CLIENT which goes in right column)
        int y = 36;
        for (int i = 0; i < cats.length; i++) {
            Module.Category cat = cats[i];
            int panelX = 10 + i * (PANEL_W + PANEL_GAP);
            if (panelX + PANEL_W > width - 10) break;
            renderCategoryPanel(ctx, mx, my, panelX, y, cat, accent);
        }

        // Settings side-panel if module selected
        if (selectedModule != null) {
            renderSettingsPanel(ctx, mx, my, width - 220, 36, selectedModule, accent);
        }

        // Bottom bar
        renderBottomBar(ctx, mx, my, accent);

        super.render(ctx, mx, my, delta);
    }

    private void renderTopBar(DrawContext ctx, int mx, int my, int accent) {
        ctx.fill(0, 0, width, 30, 0xEE0D0D14);

        // PANEL GUI label (top-left)
        DrawUtil.fillRounded(ctx, 5, 5, 60, 20, 4, 0xEE1A1A2A);
        DrawUtil.outlineRounded(ctx, 5, 5, 60, 20, 4, 1, 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "PANEL GUI", 35, 11, 0xFF888888);

        // Search bar (center)
        DrawUtil.fillRounded(ctx, width / 2 - 110, 6, 220, 18, 4, 0xEE131320);
        DrawUtil.outlineRounded(ctx, width / 2 - 110, 6, 220, 18, 4, 1, 0x33FFFFFF);
        ctx.drawTextWithShadow(textRenderer, "\uD83D\uDD0E", width / 2 - 106, 11, 0xFF666666);

        // LAYOUT (top-right)
        DrawUtil.fillRounded(ctx, width - 70, 5, 65, 20, 4, 0xEE1A1A2A);
        DrawUtil.outlineRounded(ctx, width - 70, 5, 65, 20, 4, 1, 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "LAYOUT", width - 37, 11, 0xFF888888);

        // ANTI-CHEAT toggle (far right)
        DrawUtil.fillRounded(ctx, width - 145, 5, 68, 20, 4, 0xEE1A1A2A);
        DrawUtil.outlineRounded(ctx, width - 145, 5, 68, 20, 4, 1, 0x33FFFFFF);
        ctx.drawTextWithShadow(textRenderer, "\uD83D\uDEE1 ANTI-CHEAT OFF", width - 142, 11, 0xFF888888);
    }

    private void renderCategoryPanel(DrawContext ctx, int mx, int my, int x, int y, Module.Category cat, int accent) {
        List<Module> modules = SofClient.moduleManager.getByCategory(cat);
        if (!searchQuery.isEmpty()) {
            modules = modules.stream()
                .filter(m -> m.getName().toLowerCase().contains(searchQuery))
                .collect(java.util.stream.Collectors.toList());
        }

        int panelH = HEADER_H + modules.size() * ITEM_H + 4;
        panelH = Math.min(panelH, PANEL_H_MAX);

        // Panel background
        DrawUtil.fillRounded(ctx, x, y, PANEL_W, panelH, 6, 0xEE101018);
        DrawUtil.outlineRounded(ctx, x, y, PANEL_W, panelH, 6, 1, 0x22FFFFFF);

        // Category header
        int headerBg = cat == Module.Category.CLIENT ? (accent & 0x00FFFFFF | 0x44000000) : 0xEE1A1A28;
        ctx.fill(x + 1, y + 1, x + PANEL_W - 1, y + HEADER_H, headerBg);
        ctx.drawTextWithShadow(textRenderer, cat.icon + " " + cat.name.toUpperCase(), x + 8, y + 7, accent);

        // Module list
        int itemY = y + HEADER_H;
        for (Module m : modules) {
            if (itemY + ITEM_H > y + panelH) break;

            boolean hovering = mx >= x && mx <= x + PANEL_W && my >= itemY && my <= itemY + ITEM_H;
            boolean isSelected = m == selectedModule;

            int itemBg = isSelected ? 0xEE1E1E30 : (hovering ? 0xEE181828 : 0x00000000);
            if (itemBg != 0) ctx.fill(x + 1, itemY, x + PANEL_W - 1, itemY + ITEM_H, itemBg);

            // Enabled dot
            int dotColor = m.isEnabled() ? accent : 0xFF444455;
            ctx.fill(x + 6, itemY + 8, x + 10, itemY + 12, dotColor);

            // Module name
            int textColor = m.isEnabled() ? 0xFFFFFFFF : 0xFFAAAAAA;
            ctx.drawTextWithShadow(textRenderer, m.getName(), x + 14, itemY + 6, textColor);

            // Arrow if has settings
            if (!m.getSettings().isEmpty()) {
                ctx.drawTextWithShadow(textRenderer, ">", x + PANEL_W - 12, itemY + 6, 0xFF555566);
            }

            itemY += ITEM_H;
        }
    }

    private void renderSettingsPanel(DrawContext ctx, int mx, int my, int x, int y, Module mod, int accent) {
        int panelW = 210;
        List<Module.Setting<?>> settings = mod.getSettings();
        int panelH = HEADER_H + settings.size() * 32 + 20;

        DrawUtil.fillRounded(ctx, x, y, panelW, panelH, 6, 0xF0101018);
        DrawUtil.outlineRounded(ctx, x, y, panelW, panelH, 6, 1, accent & 0x00FFFFFF | 0x55000000);

        // Header
        ctx.fill(x + 1, y + 1, x + panelW - 1, y + HEADER_H, 0xEE1A1A28);
        ctx.drawTextWithShadow(textRenderer, mod.getName().toUpperCase(), x + 8, y + 7, accent);

        // Description
        ctx.drawTextWithShadow(textRenderer, mod.getDescription(), x + 8, y + HEADER_H + 4, 0xFF666677);

        int sy = y + HEADER_H + 16;
        for (Module.Setting<?> s : settings) {
            ctx.drawTextWithShadow(textRenderer, s.name, x + 8, sy, 0xFFCCCCCC);

            if (s instanceof Module.BoolSetting bs) {
                DrawUtil.drawToggle(ctx, x + panelW - 34, sy - 2, bs.get(), accent);
            } else if (s instanceof Module.SliderSetting ss) {
                ctx.drawTextWithShadow(textRenderer,
                    String.format("%.1f", ss.get()), x + panelW - 35, sy, 0xFF888888);
                DrawUtil.drawSlider(ctx, x + 8, sy + 10, panelW - 20, ss.get(), ss.min, ss.max, accent);
            } else if (s instanceof Module.EnumSetting es) {
                DrawUtil.fillRounded(ctx, x + panelW - 70, sy - 2, 65, 14, 3, 0xFF1A1A2A);
                ctx.drawTextWithShadow(textRenderer, es.get(), x + panelW - 66, sy, 0xFFFFFFFF);
            }
            sy += 28;
        }
    }

    private void renderBottomBar(DrawContext ctx, int mx, int my, int accent) {
        int barY = height - 28;
        ctx.fill(0, barY, width, height, 0xEE0D0D14);
        DrawUtil.outlineRounded(ctx, 0, barY, width, 1, 0, 1, 0x22FFFFFF);

        String[] tabs = {"CONFIGS", "PROFILE", "HUD", "EMOTES", "SETTINGS"};
        int tabW = 80, totalW = tabs.length * tabW;
        int startX = (width - totalW) / 2;

        for (int i = 0; i < tabs.length; i++) {
            int tx = startX + i * tabW;
            boolean active = tabs[i].equals(activeTab);
            boolean hover = mx >= tx && mx <= tx + tabW && my >= barY;

            if (active) {
                DrawUtil.fillRounded(ctx, tx + 4, barY + 4, tabW - 8, 20, 4, accent & 0x00FFFFFF | 0x33000000);
                ctx.fill(tx + 4, barY + 3, tx + tabW - 4, barY + 4, accent);
            }

            int textColor = active ? accent : (hover ? 0xFFCCCCCC : 0xFF666677);
            ctx.drawCenteredTextWithShadow(textRenderer, tabs[i], tx + tabW / 2, barY + 9, textColor);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        // Check module clicks
        int y = 36;
        for (int i = 0; i < cats.length; i++) {
            Module.Category cat = cats[i];
            int panelX = 10 + i * (PANEL_W + PANEL_GAP);
            if (panelX + PANEL_W > width - 10) break;

            List<Module> modules = SofClient.moduleManager.getByCategory(cat);
            if (!searchQuery.isEmpty()) {
                modules = modules.stream()
                    .filter(m -> m.getName().toLowerCase().contains(searchQuery))
                    .collect(java.util.stream.Collectors.toList());
            }

            int itemY = y + HEADER_H;
            for (Module m : modules) {
                if (mx >= panelX && mx <= panelX + PANEL_W && my >= itemY && my <= itemY + ITEM_H) {
                    if (button == 0) {
                        m.toggle();
                        if (selectedModule == m) selectedModule = null;
                        else if (!m.getSettings().isEmpty()) selectedModule = m;
                    } else if (button == 1) {
                        selectedModule = (selectedModule == m) ? null : m;
                    }
                    return true;
                }
                itemY += ITEM_H;
            }
        }

        // Bottom bar tabs
        String[] tabs = {"CONFIGS", "PROFILE", "HUD", "EMOTES", "SETTINGS"};
        int tabW = 80, totalW = tabs.length * tabW;
        int startX = (width - totalW) / 2;
        int barY = height - 28;
        for (int i = 0; i < tabs.length; i++) {
            int tx = startX + i * tabW;
            if (mx >= tx && mx <= tx + tabW && my >= barY) {
                activeTab = tabs[i];
                if ("SETTINGS".equals(activeTab)) {
                    client.setScreen(new com.sofclient.gui.panel.SettingsScreen(this));
                }
                return true;
            }
        }

        // LAYOUT button
        if (mx >= width - 70 && mx <= width - 5 && my >= 5 && my <= 25) {
            SofClient.configManager.setGuiStyle("DROPDOWN");
            client.setScreen(new com.sofclient.gui.dropdown.DropdownScreen());
            return true;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}
