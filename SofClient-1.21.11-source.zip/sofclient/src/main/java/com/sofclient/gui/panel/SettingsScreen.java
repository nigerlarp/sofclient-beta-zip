package com.sofclient.gui.panel;

import com.sofclient.SofClient;
import com.sofclient.theme.ThemeManager;
import com.sofclient.util.DrawUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class SettingsScreen extends Screen {

    private final Screen parent;

    public SettingsScreen(Screen parent) {
        super(Text.literal("SofClient - Settings"));
        this.parent = parent;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        int accent = SofClient.themeManager.getAccentColor();

        ctx.fill(0, 0, width, height, 0xBB080810);

        int panelW = 500, panelH = 420;
        int px = (width - panelW) / 2, py = (height - panelH) / 2;

        DrawUtil.fillRounded(ctx, px, py, panelW, panelH, 10, 0xF0101018);
        DrawUtil.outlineRounded(ctx, px, py, panelW, panelH, 10, 1, 0x33FFFFFF);

        // Header
        ctx.fill(px + 1, py + 1, px + panelW - 1, py + 30, 0xEE14141E);
        ctx.drawCenteredTextWithShadow(textRenderer, "SETTINGS", px + panelW / 2, py + 10, accent);

        int y = py + 44;

        // Section: INTERFACE
        ctx.drawTextWithShadow(textRenderer, "INTERFACE", px + 20, y, 0xFF888888);
        y += 16;

        // GUI STYLE
        ctx.drawTextWithShadow(textRenderer, "GUI STYLE", px + 20, y + 2, 0xFFCCCCCC);
        String guiStyle = SofClient.configManager.getGuiStyle();
        boolean panelOn = "PANEL".equals(guiStyle);
        DrawUtil.fillRounded(ctx, px + 180, y, 100, 18, 4, panelOn ? (accent & 0x00FFFFFF | 0x44000000) : 0xFF1A1A2A);
        DrawUtil.outlineRounded(ctx, px + 180, y, 100, 18, 4, 1, panelOn ? accent : 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "PANEL", px + 230, y + 4, panelOn ? accent : 0xFFAAAAAA);
        DrawUtil.fillRounded(ctx, px + 290, y, 110, 18, 4, !panelOn ? (accent & 0x00FFFFFF | 0x44000000) : 0xFF1A1A2A);
        DrawUtil.outlineRounded(ctx, px + 290, y, 110, 18, 4, 1, !panelOn ? accent : 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "DROPDOWN", px + 345, y + 4, !panelOn ? accent : 0xFFAAAAAA);
        y += 28;

        // BACKGROUND BLUR
        ctx.drawTextWithShadow(textRenderer, "BACKGROUND BLUR", px + 20, y, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "2", px + panelW - 30, y, 0xFF888888);
        DrawUtil.drawSlider(ctx, px + 20, y + 14, panelW - 50, 2, 0, 10, accent);
        y += 32;

        // BACKDROP DIM
        ctx.drawTextWithShadow(textRenderer, "BACKDROP DIM", px + 20, y, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "40%", px + panelW - 40, y, 0xFF888888);
        DrawUtil.drawSlider(ctx, px + 20, y + 14, panelW - 50, 4, 0, 10, accent);
        y += 32;

        // MENU SCALE
        ctx.drawTextWithShadow(textRenderer, "MENU SCALE", px + 20, y, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "85%", px + panelW - 40, y, 0xFF888888);
        DrawUtil.drawSlider(ctx, px + 20, y + 14, panelW - 50, 8.5, 5, 15, accent);
        y += 32;

        // ANIMATIONS toggle
        ctx.drawTextWithShadow(textRenderer, "ANIMATIONS", px + 20, y, 0xFFCCCCCC);
        DrawUtil.drawToggle(ctx, px + panelW - 50, y - 2, true, accent);
        y += 24;

        // TOOLTIPS
        ctx.drawTextWithShadow(textRenderer, "TOOLTIPS", px + 20, y, 0xFFCCCCCC);
        DrawUtil.drawToggle(ctx, px + panelW - 50, y - 2, true, accent);
        y += 24;

        // WINDOW SHADOW
        ctx.drawTextWithShadow(textRenderer, "WINDOW SHADOW", px + 20, y, 0xFFCCCCCC);
        DrawUtil.drawToggle(ctx, px + panelW - 50, y - 2, true, accent);
        y += 32;

        // Section: THEME
        ctx.drawTextWithShadow(textRenderer, "THEME", px + 20, y, 0xFF888888);
        y += 16;

        ThemeManager.Theme[] themes = ThemeManager.Theme.values();
        int themeX = px + 20;
        for (ThemeManager.Theme t : themes) {
            boolean active = SofClient.themeManager.getCurrent() == t;
            int themeColor = getThemePreviewColor(t);
            int btnW = 56;
            DrawUtil.fillRounded(ctx, themeX, y, btnW, 22, 4, active ? (themeColor & 0x00FFFFFF | 0x44000000) : 0xFF131320);
            DrawUtil.outlineRounded(ctx, themeX, y, btnW, 22, 4, 1, active ? themeColor : 0x33FFFFFF);
            ctx.fill(themeX + 6, y + 7, themeX + 14, y + 15, themeColor);
            ctx.drawTextWithShadow(textRenderer, t.displayName, themeX + 18, y + 6, active ? themeColor : 0xFFAAAAAA);
            themeX += btnW + 6;
            if (themeX + btnW > px + panelW - 20) { themeX = px + 20; y += 28; }
        }
        y += 30;

        // Back button
        DrawUtil.fillRounded(ctx, px + panelW / 2 - 60, py + panelH - 36, 120, 22, 5, 0xFF1A1A2A);
        DrawUtil.outlineRounded(ctx, px + panelW / 2 - 60, py + panelH - 36, 120, 22, 5, 1, 0x33FFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "\u2190 BACK", px + panelW / 2, py + panelH - 28, 0xFFAAAAAA);

        super.render(ctx, mx, my, delta);
    }

    private int getThemePreviewColor(ThemeManager.Theme t) {
        return switch (t) {
            case DEFAULT -> 0xFFFF6EB4;
            case PINK    -> 0xFFFF4FA3;
            case BLUE    -> 0xFF4FA8FF;
            case GREEN   -> 0xFF4FFF9A;
            case PURPLE  -> 0xFFB44FFF;
            case RED     -> 0xFFFF4F4F;
            case RAINBOW -> SofClient.themeManager.getAccentColor();
            case CUSTOM  -> SofClient.themeManager.getCustomColor();
        };
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int panelW = 500, panelH = 420;
        int px = (width - panelW) / 2, py = (height - panelH) / 2;

        // GUI Style
        int y = py + 60;
        if (mx >= px + 180 && mx <= px + 280 && my >= y && my <= y + 18) {
            SofClient.configManager.setGuiStyle("PANEL");
        } else if (mx >= px + 290 && mx <= px + 400 && my >= y && my <= y + 18) {
            SofClient.configManager.setGuiStyle("DROPDOWN");
        }

        // Theme buttons
        y = py + 44 + 16 + 28 + 32 + 32 + 32 + 24 + 24 + 32 + 16;
        ThemeManager.Theme[] themes = ThemeManager.Theme.values();
        int themeX = px + 20;
        for (ThemeManager.Theme t : themes) {
            int btnW = 56;
            if (mx >= themeX && mx <= themeX + btnW && my >= y && my <= y + 22) {
                SofClient.themeManager.setCurrent(t);
                SofClient.configManager.setTheme(t.name());
                break;
            }
            themeX += btnW + 6;
        }

        // Back button
        if (mx >= px + panelW / 2 - 60 && mx <= px + panelW / 2 + 60 && my >= py + panelH - 36 && my <= py + panelH - 14) {
            client.setScreen(parent);
            return true;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}
