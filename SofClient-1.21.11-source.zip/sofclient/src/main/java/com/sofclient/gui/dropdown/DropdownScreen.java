package com.sofclient.gui.dropdown;

import com.sofclient.SofClient;
import com.sofclient.modules.Module;
import com.sofclient.theme.ThemeManager;
import com.sofclient.util.DrawUtil;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.List;
import java.util.stream.Collectors;

public class DropdownScreen extends Screen {

    private Module.Category selectedCategory = Module.Category.COMBAT;
    private Module selectedModule = null;
    private TextFieldWidget searchField;
    private String searchQuery = "";

    // Panel dims
    private static final int WIN_X = 60, WIN_Y = 30;
    private static final int WIN_W = 680, WIN_H = 420;
    private static final int SIDEBAR_W = 140;
    private static final int TAB_H = 36;
    private static final int ITEM_H = 36;
    private static final int ITEM_W = 220;

    private String activeTab = "MODULES";

    public DropdownScreen() {
        super(Text.literal("SofClient"));
    }

    @Override
    protected void init() {
        searchField = new TextFieldWidget(textRenderer,
            WIN_X + SIDEBAR_W + 20, WIN_Y + TAB_H + 8, 180, 16, Text.literal(""));
        searchField.setMaxLength(50);
        searchField.setPlaceholder(Text.literal("Search modules"));
        searchField.setDrawsBackground(false);
        addDrawableChild(searchField);
    }

    @Override
    public void tick() {
        SofClient.themeManager.tick();
        searchQuery = searchField.getText().toLowerCase();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        int accent = SofClient.themeManager.getAccentColor();

        ctx.fill(0, 0, width, height, 0xBB080810);

        // Window shadow
        DrawUtil.fillRounded(ctx, WIN_X + 4, WIN_Y + 4, WIN_W, WIN_H, 10, 0x44000000);

        // Window background
        DrawUtil.fillRounded(ctx, WIN_X, WIN_Y, WIN_W, WIN_H, 10, 0xF0101018);
        DrawUtil.outlineRounded(ctx, WIN_X, WIN_Y, WIN_W, WIN_H, 10, 1, 0x22FFFFFF);

        // Top tab bar
        renderTabBar(ctx, mx, my, accent);

        if ("MODULES".equals(activeTab)) {
            renderSidebar(ctx, mx, my, accent);
            renderModuleGrid(ctx, mx, my, accent);
            if (selectedModule != null) {
                renderSettingsSide(ctx, mx, my, accent);
            }
        } else if ("SETTINGS".equals(activeTab)) {
            renderSettingsTab(ctx, mx, my, accent);
        }

        super.render(ctx, mx, my, delta);
    }

    private void renderTabBar(DrawContext ctx, int mx, int my, int accent) {
        // Header background
        ctx.fill(WIN_X + 1, WIN_Y + 1, WIN_X + WIN_W - 1, WIN_Y + TAB_H, 0xEE14141E);

        // 67 logo
        ctx.drawTextWithShadow(textRenderer, "SOF", WIN_X + 10, WIN_Y + 12, accent);

        String[] tabs = {"MODULES", "HUD", "EMOTES", "CONFIGS", "PROFILE", "SETTINGS"};
        int tx = WIN_X + 55;
        for (String tab : tabs) {
            boolean active = tab.equals(activeTab);
            boolean hover = mx >= tx - 2 && mx <= tx + textRenderer.getWidth(tab) + 10 && my >= WIN_Y && my <= WIN_Y + TAB_H;
            int tcolor = active ? accent : (hover ? 0xFFCCCCCC : 0xFF666677);
            ctx.drawTextWithShadow(textRenderer, tab, tx, WIN_Y + 13, tcolor);
            if (active) ctx.fill(tx - 2, WIN_Y + TAB_H - 2, tx + textRenderer.getWidth(tab) + 10, WIN_Y + TAB_H, accent);
            tx += textRenderer.getWidth(tab) + 18;
        }

        // Dropdown button (top-right)
        int btnX = WIN_X + WIN_W - 100;
        DrawUtil.fillRounded(ctx, btnX, WIN_Y + 8, 90, 20, 4, 0xFF1A1A2A);
        DrawUtil.outlineRounded(ctx, btnX, WIN_Y + 8, 90, 20, 4, 1, 0x33FFFFFF);
        ctx.drawTextWithShadow(textRenderer, "DROPDOWN v", btnX + 8, WIN_Y + 13, 0xFF888888);

        // X close
        ctx.drawTextWithShadow(textRenderer, "\u00D7", WIN_X + WIN_W - 14, WIN_Y + 11, 0xFF666666);
    }

    private void renderSidebar(DrawContext ctx, int mx, int my, int accent) {
        int sx = WIN_X;
        ctx.fill(sx + 1, WIN_Y + TAB_H, sx + SIDEBAR_W, WIN_Y + WIN_H - 1, 0xEE0E0E18);

        int sy = WIN_Y + TAB_H + 8;
        for (Module.Category cat : Module.Category.values()) {
            boolean active = cat == selectedCategory;
            boolean hover = mx >= sx && mx <= sx + SIDEBAR_W && my >= sy && my <= sy + 24;

            if (active) {
                ctx.fill(sx + 1, sy, sx + SIDEBAR_W, sy + 24, 0xEE1E1E2E);
                ctx.fill(sx + 1, sy, sx + 3, sy + 24, accent);
            } else if (hover) {
                ctx.fill(sx + 1, sy, sx + SIDEBAR_W, sy + 24, 0xEE181822);
            }

            int textColor = active ? accent : (hover ? 0xFFCCCCCC : 0xFF888888);
            ctx.drawTextWithShadow(textRenderer, cat.icon + " " + cat.name.toUpperCase(), sx + 12, sy + 7, textColor);

            sy += 28;
        }

        // Anti-cheat toggle at bottom
        int acY = WIN_Y + WIN_H - 36;
        ctx.fill(sx + 1, acY, sx + SIDEBAR_W, acY + 28, 0xEE0E0E18);
        ctx.drawTextWithShadow(textRenderer, "\uD83D\uDEE1 ANTI-CHEAT OFF", sx + 6, acY + 10, 0xFF666677);
    }

    private void renderModuleGrid(DrawContext ctx, int mx, int my, int accent) {
        int gridX = WIN_X + SIDEBAR_W;
        int gridY = WIN_Y + TAB_H;
        int gridW = selectedModule != null ? WIN_W - SIDEBAR_W - 220 : WIN_W - SIDEBAR_W;
        int gridH = WIN_H - TAB_H;

        // Background
        ctx.fill(gridX, gridY, WIN_X + WIN_W - 1, WIN_Y + WIN_H - 1, 0xEE0D0D14);

        // Search bar area
        ctx.fill(gridX, gridY, gridX + gridW, gridY + 30, 0xEE101018);
        DrawUtil.fillRounded(ctx, gridX + 10, gridY + 7, 170, 16, 3, 0xFF131320);
        ctx.drawTextWithShadow(textRenderer, "\uD83D\uDD0E", gridX + 14, gridY + 11, 0xFF555566);

        List<Module> modules = SofClient.moduleManager.getByCategory(selectedCategory);
        if (!searchQuery.isEmpty()) {
            modules = modules.stream().filter(m -> m.getName().toLowerCase().contains(searchQuery)).collect(Collectors.toList());
        }

        // Module count
        ctx.drawTextWithShadow(textRenderer, modules.size() + " MODULES", gridX + gridW - 70, gridY + 11, 0xFF555566);

        int cols = gridW > 400 ? 2 : 1;
        int colW = (gridW - 20) / cols;
        int itemX = gridX + 10;
        int itemY = gridY + 36;
        int col = 0;

        for (Module m : modules) {
            if (itemY + ITEM_H > WIN_Y + WIN_H - 4) break;

            boolean hover = mx >= itemX && mx <= itemX + colW - 4 && my >= itemY && my <= itemY + ITEM_H - 2;
            boolean sel = m == selectedModule;

            int itemBg = sel ? 0xEE1E1E30 : (hover ? 0xEE181828 : 0xEE131320);
            DrawUtil.fillRounded(ctx, itemX, itemY, colW - 4, ITEM_H - 2, 4, itemBg);
            if (sel) DrawUtil.outlineRounded(ctx, itemX, itemY, colW - 4, ITEM_H - 2, 4, 1, accent & 0x00FFFFFF | 0x55000000);

            // Module name
            ctx.drawTextWithShadow(textRenderer, m.getName().toUpperCase(), itemX + 10, itemY + 6, 0xFFCCCCCC);

            // Description (truncated)
            String desc = m.getDescription();
            if (desc.length() > 28) desc = desc.substring(0, 25) + "...";
            ctx.drawTextWithShadow(textRenderer, desc, itemX + 10, itemY + 18, 0xFF555566);

            // Keybind indicator
            if (m.getKeybind() != -1) {
                String kb = "[" + m.getKeybind() + "]";
                ctx.drawTextWithShadow(textRenderer, kb, itemX + colW - 50, itemY + 6, 0xFF555566);
            }

            // Toggle
            DrawUtil.drawToggle(ctx, itemX + colW - 36, itemY + 10, m.isEnabled(), accent);

            col++;
            if (col >= cols) {
                col = 0;
                itemX = gridX + 10;
                itemY += ITEM_H;
            } else {
                itemX += colW;
            }
        }
    }

    private void renderSettingsSide(DrawContext ctx, int mx, int my, int accent) {
        int sx = WIN_X + WIN_W - 220;
        ctx.fill(sx, WIN_Y + TAB_H, WIN_X + WIN_W - 1, WIN_Y + WIN_H - 1, 0xEE0F0F1A);
        DrawUtil.outlineRounded(ctx, sx, WIN_Y + TAB_H, 220, WIN_H - TAB_H, 0, 1, 0x22FFFFFF);

        // Header
        ctx.drawTextWithShadow(textRenderer, selectedModule.getName().toUpperCase(), sx + 10, WIN_Y + TAB_H + 10, accent);
        ctx.drawTextWithShadow(textRenderer, selectedModule.getDescription(), sx + 10, WIN_Y + TAB_H + 22, 0xFF555566);

        // Settings
        int sy = WIN_Y + TAB_H + 44;
        for (Module.Setting<?> s : selectedModule.getSettings()) {
            if (sy > WIN_Y + WIN_H - 20) break;
            ctx.drawTextWithShadow(textRenderer, s.name, sx + 10, sy, 0xFFCCCCCC);

            if (s instanceof Module.BoolSetting bs) {
                DrawUtil.drawToggle(ctx, sx + 185, sy - 2, bs.get(), accent);
            } else if (s instanceof Module.SliderSetting ss) {
                ctx.drawTextWithShadow(textRenderer, String.format("%.1f", ss.get()), sx + 185, sy, 0xFF888888);
                DrawUtil.drawSlider(ctx, sx + 10, sy + 11, 190, ss.get(), ss.min, ss.max, accent);
                sy += 10;
            } else if (s instanceof Module.EnumSetting es) {
                DrawUtil.fillRounded(ctx, sx + 155, sy - 2, 55, 14, 3, 0xFF1A1A2A);
                ctx.drawTextWithShadow(textRenderer, es.get(), sx + 158, sy, 0xFFFFFFFF);
            }
            sy += 26;
        }
    }

    private void renderSettingsTab(DrawContext ctx, int mx, int my, int accent) {
        // Delegate to same settings rendering as panel
        int y = WIN_Y + TAB_H + 20;
        ctx.fill(WIN_X + 1, WIN_Y + TAB_H, WIN_X + WIN_W - 1, WIN_Y + WIN_H - 1, 0xEE0D0D14);
        ctx.drawTextWithShadow(textRenderer, "INTERFACE", WIN_X + 24, y, 0xFF888888);
        y += 20;
        ctx.drawTextWithShadow(textRenderer, "GUI STYLE", WIN_X + 24, y, 0xFFCCCCCC);
        // Panel/Dropdown toggles
        DrawUtil.fillRounded(ctx, WIN_X + 220, y - 2, 90, 18, 4, 0xFF1A1A2A);
        ctx.drawCenteredTextWithShadow(textRenderer, "PANEL", WIN_X + 265, y + 2, 0xFFAAAAAA);
        DrawUtil.fillRounded(ctx, WIN_X + 320, y - 2, 110, 18, 4, accent & 0x00FFFFFF | 0x44000000);
        DrawUtil.outlineRounded(ctx, WIN_X + 320, y - 2, 110, 18, 4, 1, accent);
        ctx.drawCenteredTextWithShadow(textRenderer, "DROPDOWN", WIN_X + 375, y + 2, accent);

        y += 28;
        ctx.drawTextWithShadow(textRenderer, "BACKGROUND BLUR", WIN_X + 24, y, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "2", WIN_X + WIN_W - 40, y, 0xFF888888);
        DrawUtil.drawSlider(ctx, WIN_X + 24, y + 14, WIN_W - 60, 2, 0, 10, accent);
        y += 32;
        ctx.drawTextWithShadow(textRenderer, "BACKDROP DIM", WIN_X + 24, y, 0xFFCCCCCC);
        ctx.drawTextWithShadow(textRenderer, "40%", WIN_X + WIN_W - 50, y, 0xFF888888);
        DrawUtil.drawSlider(ctx, WIN_X + 24, y + 14, WIN_W - 60, 4, 0, 10, accent);
        y += 32;
        ctx.drawTextWithShadow(textRenderer, "ANIMATIONS", WIN_X + 24, y, 0xFFCCCCCC);
        DrawUtil.drawToggle(ctx, WIN_X + WIN_W - 60, y - 2, true, accent);
        y += 26;
        ctx.drawTextWithShadow(textRenderer, "TOOLTIPS", WIN_X + 24, y, 0xFFCCCCCC);
        DrawUtil.drawToggle(ctx, WIN_X + WIN_W - 60, y - 2, true, accent);
        y += 26;
        ctx.drawTextWithShadow(textRenderer, "WINDOW SHADOW", WIN_X + 24, y, 0xFFCCCCCC);
        DrawUtil.drawToggle(ctx, WIN_X + WIN_W - 60, y - 2, true, accent);
        y += 36;

        // Themes
        ctx.drawTextWithShadow(textRenderer, "THEME", WIN_X + 24, y, 0xFF888888);
        y += 16;
        int themeX = WIN_X + 24;
        for (ThemeManager.Theme t : ThemeManager.Theme.values()) {
            boolean active = SofClient.themeManager.getCurrent() == t;
            int tc = getPreviewColor(t);
            int btnW = 60;
            DrawUtil.fillRounded(ctx, themeX, y, btnW, 22, 4, active ? (tc & 0x00FFFFFF | 0x44000000) : 0xFF131320);
            DrawUtil.outlineRounded(ctx, themeX, y, btnW, 22, 4, 1, active ? tc : 0x33FFFFFF);
            ctx.fill(themeX + 6, y + 7, themeX + 14, y + 15, tc);
            ctx.drawTextWithShadow(textRenderer, t.displayName, themeX + 18, y + 6, active ? tc : 0xFFAAAAAA);
            themeX += btnW + 6;
            if (themeX + btnW > WIN_X + WIN_W - 20) { themeX = WIN_X + 24; y += 28; }
        }
    }

    private int getPreviewColor(ThemeManager.Theme t) {
        return switch (t) {
            case DEFAULT -> 0xFFFF6EB4;
            case PINK    -> 0xFFFF4FA3;
            case BLUE    -> 0xFF4FA8FF;
            case GREEN   -> 0xFF4FFF9A;
            case PURPLE  -> 0xFFB44FFF;
            case RED     -> 0xFFFF4F4F;
            case RAINBOW -> SofClient.themeManager.getAccentColor();
            case CUSTOM  -> SofClient.themeManager.getCustomColor();
        };
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int accent = SofClient.themeManager.getAccentColor();

        // Tab bar clicks
        String[] tabs = {"MODULES", "HUD", "EMOTES", "CONFIGS", "PROFILE", "SETTINGS"};
        int tx = WIN_X + 55;
        for (String tab : tabs) {
            int tw = textRenderer.getWidth(tab) + 12;
            if (mx >= tx - 2 && mx <= tx + tw && my >= WIN_Y && my <= WIN_Y + TAB_H) {
                activeTab = tab;
                return true;
            }
            tx += textRenderer.getWidth(tab) + 18;
        }

        // X close
        if (mx >= WIN_X + WIN_W - 18 && mx <= WIN_X + WIN_W - 4 && my >= WIN_Y + 7 && my <= WIN_Y + TAB_H) {
            client.setScreen(null);
            return true;
        }

        // DROPDOWN -> PANEL switch
        if (mx >= WIN_X + WIN_W - 100 && mx <= WIN_X + WIN_W - 10 && my >= WIN_Y + 8 && my <= WIN_Y + 28) {
            SofClient.configManager.setGuiStyle("PANEL");
            client.setScreen(new com.sofclient.gui.panel.PanelScreen());
            return true;
        }

        if (!"MODULES".equals(activeTab)) return super.mouseClicked(mx, my, button);

        // Sidebar category
        int sy = WIN_Y + TAB_H + 8;
        for (Module.Category cat : Module.Category.values()) {
            if (mx >= WIN_X && mx <= WIN_X + SIDEBAR_W && my >= sy && my <= sy + 24) {
                selectedCategory = cat;
                selectedModule = null;
                return true;
            }
            sy += 28;
        }

        // Module grid clicks
        int gridX = WIN_X + SIDEBAR_W;
        int gridY = WIN_Y + TAB_H + 36;
        int gridW = selectedModule != null ? WIN_W - SIDEBAR_W - 220 : WIN_W - SIDEBAR_W;
        int cols = gridW > 400 ? 2 : 1;
        int colW = (gridW - 20) / cols;

        List<Module> modules = SofClient.moduleManager.getByCategory(selectedCategory);
        if (!searchQuery.isEmpty()) {
            modules = modules.stream().filter(m -> m.getName().toLowerCase().contains(searchQuery)).collect(Collectors.toList());
        }

        int itemX = gridX + 10, itemY = gridY;
        int col = 0;
        for (Module m : modules) {
            if (mx >= itemX && mx <= itemX + colW - 4 && my >= itemY && my <= itemY + ITEM_H - 2) {
                if (button == 0) {
                    // Check if toggle was clicked
                    if (mx >= itemX + colW - 36 && mx <= itemX + colW - 12) {
                        m.toggle();
                    } else {
                        selectedModule = (selectedModule == m) ? null : m;
                    }
                } else if (button == 1) {
                    m.toggle();
                }
                return true;
            }
            col++;
            if (col >= cols) { col = 0; itemX = gridX + 10; itemY += ITEM_H; }
            else itemX += colW;
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean shouldPause() { return false; }
}
